(() => {
  'use strict';

  const ROUTE_KEY = 'x79.ui.route.v2';
  const CONNECT_DURATION = 2000;
  const ROUTES = Object.freeze({ WELCOME: 'welcome', CONNECT: 'connect', LOBBY: 'lobby' });

  const screens = [...document.querySelectorAll('.screen')];
  const authModal = document.getElementById('authModal');
  const authClose = document.getElementById('authClose');
  const authTitle = document.getElementById('authTitle');
  const authMessage = document.getElementById('authMessage');
  const tabs = [...document.querySelectorAll('[data-auth-tab]')];
  const forms = [...document.querySelectorAll('[data-auth-form]')];
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  const connectPercent = document.getElementById('connectPercent');
  const connectStatus = document.getElementById('connectStatus');
  const connectProgressBar = document.getElementById('connectProgressBar');
  const lobbyToast = document.getElementById('lobbyToast');
  const logoutButton = document.getElementById('logoutButton');

  let currentRoute = ROUTES.WELCOME;
  let authBusy = false;
  let transitionBusy = false;
  let toastTimer = 0;
  let connectFrame = 0;
  let leavingTimer = 0;

  function persistRoute(route) {
    currentRoute = route;
    sessionStorage.setItem(ROUTE_KEY, route);
    history.replaceState({ x79Route: route }, '', location.pathname + location.search);
  }

  function showScreen(id, { persist = true } = {}) {
    const next = document.getElementById(id);
    if (!next) return;
    const previous = screens.find(screen => screen.classList.contains('is-active') && screen !== next);

    clearTimeout(leavingTimer);
    if (previous) {
      previous.classList.add('is-leaving');
      previous.classList.remove('is-active');
      leavingTimer = window.setTimeout(() => previous.classList.remove('is-leaving'), 330);
    }

    screens.forEach(screen => {
      const active = screen === next;
      if (!active && screen !== previous) screen.classList.remove('is-active', 'is-leaving');
      screen.setAttribute('aria-hidden', String(!active));
    });

    next.classList.remove('is-leaving');
    next.classList.add('is-active');
    next.setAttribute('aria-hidden', 'false');

    if (persist) persistRoute(id);
    else currentRoute = id;
  }

  function setAuthTab(type) {
    if (authBusy) return;
    const isLogin = type === 'login';
    authTitle.textContent = isLogin ? 'ĐĂNG NHẬP' : 'ĐĂNG KÝ';
    authMessage.textContent = '';

    tabs.forEach(tab => {
      const active = tab.dataset.authTab === type;
      tab.classList.toggle('is-active', active);
      tab.setAttribute('aria-selected', String(active));
    });

    forms.forEach(form => form.classList.toggle('is-active', form.dataset.authForm === type));
  }

  function openAuth(type) {
    if (transitionBusy || currentRoute !== ROUTES.WELCOME) return;
    setAuthTab(type);
    authModal.classList.add('is-open');
    authModal.setAttribute('aria-hidden', 'false');
    window.setTimeout(() => document.querySelector('.auth-form.is-active input')?.focus({ preventScroll: true }), 180);
  }

  function closeAuth(force = false) {
    if (authBusy && !force) return;
    authModal.classList.remove('is-open');
    authModal.setAttribute('aria-hidden', 'true');
  }

  function setFormsDisabled(disabled) {
    authBusy = disabled;
    forms.forEach(form => [...form.elements].forEach(el => { el.disabled = disabled; }));
    tabs.forEach(tab => { tab.disabled = disabled; });
    authClose.disabled = disabled;
  }

  function validateRegister() {
    const pass = registerForm.elements.password.value;
    const confirm = registerForm.elements.passwordConfirm.value;
    if (pass !== confirm) {
      authMessage.textContent = 'Mật khẩu nhập lại chưa khớp.';
      registerForm.elements.passwordConfirm.focus();
      return false;
    }
    return true;
  }

  function statusFor(percent) {
    if (percent < 28) return 'Đang xác thực tài khoản...';
    if (percent < 62) return 'Đang kết nối máy chủ...';
    if (percent < 90) return 'Đang đồng bộ dữ liệu...';
    if (percent < 100) return 'Đang hoàn tất...';
    return 'Hoàn tất';
  }

  function resetConnectionUI() {
    cancelAnimationFrame(connectFrame);
    connectFrame = 0;
    connectPercent.textContent = '0%';
    connectProgressBar.style.width = '0%';
    connectStatus.textContent = statusFor(0);
  }

  function runConnection() {
    if (transitionBusy) return;
    transitionBusy = true;
    closeAuth(true);
    resetConnectionUI();
    showScreen(ROUTES.CONNECT);

    const start = performance.now();
    const tick = now => {
      const elapsed = now - start;
      const raw = Math.min(1, elapsed / CONNECT_DURATION);
      const eased = 1 - Math.pow(1 - raw, 2.15);
      const percent = raw >= 1 ? 100 : Math.min(99, Math.floor(eased * 100));

      connectPercent.textContent = `${percent}%`;
      connectProgressBar.style.width = `${percent}%`;
      connectStatus.textContent = statusFor(percent);

      if (raw < 1) {
        connectFrame = requestAnimationFrame(tick);
        return;
      }

      connectPercent.textContent = '100%';
      connectProgressBar.style.width = '100%';
      connectStatus.textContent = 'Hoàn tất';
      showScreen(ROUTES.LOBBY);
      transitionBusy = false;
      setFormsDisabled(false);
    };

    connectFrame = requestAnimationFrame(tick);
  }

  function handleSubmit(event, type) {
    event.preventDefault();
    if (authBusy || transitionBusy || currentRoute !== ROUTES.WELCOME) return;
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    if (type === 'register' && !validateRegister()) return;

    setFormsDisabled(true);
    authMessage.textContent = type === 'login' ? 'Đang đăng nhập...' : 'Đang tạo tài khoản...';
    runConnection();
  }

  function logout() {
    if (transitionBusy) return;
    transitionBusy = true;
    cancelAnimationFrame(connectFrame);
    sessionStorage.removeItem(ROUTE_KEY);
    closeAuth(true);
    loginForm.reset();
    registerForm.reset();
    authMessage.textContent = '';
    setFormsDisabled(false);
    resetConnectionUI();
    history.replaceState({ x79Route: ROUTES.WELCOME }, '', location.pathname + location.search);
    showScreen(ROUTES.WELCOME, { persist: false });
    currentRoute = ROUTES.WELCOME;
    window.setTimeout(() => { transitionBusy = false; }, 330);
  }

  function showToast(message) {
    lobbyToast.textContent = message;
    lobbyToast.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => lobbyToast.classList.remove('is-visible'), 1350);
  }

  document.querySelectorAll('[data-open-auth]').forEach(button => {
    button.addEventListener('click', () => openAuth(button.dataset.openAuth));
  });

  tabs.forEach(tab => tab.addEventListener('click', () => setAuthTab(tab.dataset.authTab)));
  authClose.addEventListener('click', () => closeAuth());
  authModal.addEventListener('pointerdown', event => { if (event.target === authModal) closeAuth(); });

  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && authModal.classList.contains('is-open')) closeAuth();
  });

  document.getElementById('forgotPassword').addEventListener('click', () => {
    authMessage.textContent = 'Vui lòng sử dụng kênh hỗ trợ tài khoản.';
  });

  loginForm.addEventListener('submit', event => handleSubmit(event, 'login'));
  registerForm.addEventListener('submit', event => handleSubmit(event, 'register'));
  logoutButton.addEventListener('click', logout);

  document.querySelectorAll('[data-game]').forEach(button => {
    let locked = false;
    button.addEventListener('click', () => {
      if (locked || currentRoute !== ROUTES.LOBBY) return;
      locked = true;
      showToast(button.dataset.game);
      window.setTimeout(() => { locked = false; }, 360);
    });
  });

  document.querySelectorAll('[data-action]').forEach(button => {
    let locked = false;
    button.addEventListener('click', () => {
      if (locked || currentRoute !== ROUTES.LOBBY) return;
      locked = true;
      showToast(button.dataset.action);
      window.setTimeout(() => { locked = false; }, 360);
    });
  });

  window.addEventListener('popstate', () => {
    if (currentRoute === ROUTES.LOBBY) {
      history.replaceState({ x79Route: ROUTES.LOBBY }, '', location.pathname + location.search);
      showScreen(ROUTES.LOBBY, { persist: false });
      return;
    }
    if (currentRoute === ROUTES.CONNECT) {
      history.replaceState({ x79Route: ROUTES.CONNECT }, '', location.pathname + location.search);
      showScreen(ROUTES.CONNECT, { persist: false });
      return;
    }
    showScreen(ROUTES.WELCOME, { persist: false });
  });

  const savedRoute = sessionStorage.getItem(ROUTE_KEY);
  if (savedRoute === ROUTES.LOBBY) {
    showScreen(ROUTES.LOBBY);
  } else if (savedRoute === ROUTES.CONNECT) {
    currentRoute = ROUTES.WELCOME;
    runConnection();
  } else {
    showScreen(ROUTES.WELCOME);
  }
})();
