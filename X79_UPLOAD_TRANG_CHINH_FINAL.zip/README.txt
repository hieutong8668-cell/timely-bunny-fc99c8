X79 PRODUCTION UI ROUTING FINAL — 2026-08-11

Luồng: Mở đầu → Đăng nhập/Đăng ký → Kết nối 2 giây → Sảnh game.
Back không quay về Login khi đang ở Lobby. Chỉ nút ĐĂNG XUẤT trả về màn đầu.
Assets dùng đúng bộ hình cuối trong thư mục assets/.
Deploy Netlify: publish directory = . ; không cần build command.
